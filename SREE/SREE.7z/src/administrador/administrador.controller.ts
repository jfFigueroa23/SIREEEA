import { Controller } from '@nestjs/common';

@Controller('administrador')
export class AdministradorController {}
