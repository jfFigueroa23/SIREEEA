export class RespuestasCompactadasDto {
    nro_cuenta: number;
    respuestas_compactadas: string;
    grupo: number;
}