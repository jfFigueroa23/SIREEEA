export class ModeloFelder {
    activo: number = 0;
    reflexivo: number = 0;
    sensorial: number = 0;
    intuitivo: number = 0;
    visual: number = 0;
    verbal: number = 0;
    secuencial: number = 0;
    global: number = 0;
    aux_1: any;
    aux_2: any;
    aux_3: any;
    aux_4: any;
    a: string = "";
  }