export class ProfesorDTO {
    id_profesor: number;
    nombre_profesor: string;
  }