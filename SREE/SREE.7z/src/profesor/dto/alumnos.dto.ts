export class AlumnosImportData{
    nro_cuenta: number;
    contraseña: string;
    nombre: string;
    apellido_1: string;
    apellido_2: string;
    fecha_nacimiento: Date;
    grupo: number;
}