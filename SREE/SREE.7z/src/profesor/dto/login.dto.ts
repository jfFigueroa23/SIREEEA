export class LoginDto {
    nro_empleado: number;
    contra: string;
}
  